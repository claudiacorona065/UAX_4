"""Funciones sencillas para limpiar textos en español e inglés."""

import unicodedata


class NLPfunct:
    """Limpia textos y selecciona el tratamiento según el idioma."""

    _IDIOMAS_SOPORTADOS = {"es", "en"}
    _MODELOS_SPACY = {
        "es": "es_core_news_sm",
        "en": "en_core_web_sm",
    }
    _modelos_cargados = {}

    @classmethod
    def _validar_idioma(cls, idioma: str) -> str:
        """Valida y normaliza un código de idioma."""
        if not isinstance(idioma, str):
            raise TypeError("idioma debe ser una cadena de caracteres")

        idioma = idioma.lower().strip()
        if idioma not in cls._IDIOMAS_SOPORTADOS:
            raise ValueError("idioma debe ser 'es' o 'en'")
        return idioma

    @classmethod
    def _obtener_modelo_spacy(cls, idioma: str):
        """Carga una sola vez el modelo de spaCy correspondiente al idioma."""
        idioma = cls._validar_idioma(idioma)
        if idioma not in cls._modelos_cargados:
            import spacy

            nombre_modelo = cls._MODELOS_SPACY[idioma]
            try:
                cls._modelos_cargados[idioma] = spacy.load(nombre_modelo)
            except OSError as error:
                raise OSError(
                    f"No se encuentra el modelo de spaCy '{nombre_modelo}'. "
                    f"Instálalo con: python -m spacy download {nombre_modelo}"
                ) from error
        return cls._modelos_cargados[idioma]

    @staticmethod
    def _quitar_puntuacion(texto: str) -> str:
        """Sustituye cualquier signo de puntuación Unicode por un espacio."""
        sin_puntuacion = "".join(
            " " if unicodedata.category(caracter).startswith("P") else caracter
            for caracter in texto
        )
        return " ".join(sin_puntuacion.split())

    @classmethod
    def _limpiar_espanol(cls, texto: str) -> str:
        """Convierte un texto en español a minúsculas y elimina la puntuación."""
        return cls._quitar_puntuacion(texto.lower())

    @classmethod
    def _limpiar_ingles(cls, texto: str) -> str:
        """Convierte un texto en inglés a minúsculas y elimina la puntuación."""
        return cls._quitar_puntuacion(texto.lower())

    @classmethod
    def clean_text(cls, texto: str, idioma: str, testing: int = 0) -> str:
        """Limpia ``texto`` usando la ruta de español (es) o inglés (en).

        Args:
            texto: Cadena que se quiere limpiar.
            idioma: Código del idioma: ``"es"`` o ``"en"``.
            testing: Si vale 1, muestra el resultado. Se mantiene por
                compatibilidad con los ejemplos de los cuadernos.

        Returns:
            El texto en minúsculas, sin puntuación y con espacios normalizados.

        Raises:
            TypeError: Si ``texto`` o ``idioma`` no son cadenas.
            ValueError: Si el idioma no es ``"es"`` ni ``"en"``.
        """
        if not isinstance(texto, str):
            raise TypeError("texto debe ser una cadena de caracteres")
        idioma = cls._validar_idioma(idioma)
        limpiadores = {
            "es": cls._limpiar_espanol,
            "en": cls._limpiar_ingles,
        }

        resultado = limpiadores[idioma](texto)
        if testing == 1:
            print("Texto limpio:", resultado)
        return resultado

    @classmethod
    def tokenizer_spc(cls, texto: str, idioma: str) -> list[str]:
        """Tokeniza un texto con el modelo de spaCy del idioma indicado."""
        if not isinstance(texto, str):
            raise TypeError("texto debe ser una cadena de caracteres")

        modelo = cls._obtener_modelo_spacy(idioma)
        return [token.text for token in modelo(texto) if not token.is_space]

    @classmethod
    def stopwords_spc(
        cls, texto: str, idioma: str, formato: str = "list"
    ) -> list:
        """Elimina las stop-words de spaCy y devuelve textos o tokens.

        ``formato="list"`` devuelve una lista de cadenas. Con
        ``formato="listall"`` se devuelven los objetos ``Token`` completos,
        necesarios para consultar atributos como ``lemma_`` y ``pos_``.
        """
        if not isinstance(texto, str):
            raise TypeError("texto debe ser una cadena de caracteres")
        if formato not in {"list", "listall"}:
            raise ValueError("formato debe ser 'list' o 'listall'")

        modelo = cls._obtener_modelo_spacy(idioma)
        tokens = [
            token for token in modelo(texto)
            if not token.is_stop and not token.is_space
        ]
        if formato == "listall":
            return tokens
        return [token.text for token in tokens]


def clean_text(texto: str, idioma: str) -> str:
    """Limpia un texto en español (es) o inglés (en)."""
    return NLPfunct.clean_text(texto, idioma)
